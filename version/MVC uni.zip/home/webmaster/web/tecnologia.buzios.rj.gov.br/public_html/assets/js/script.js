// assets/js/script.js
// Scripts customizados podem ser adicionados aqui.

