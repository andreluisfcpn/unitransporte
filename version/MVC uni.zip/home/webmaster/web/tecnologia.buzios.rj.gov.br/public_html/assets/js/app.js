var app = angular.module('UserApp', []);

app.controller('UserController', function ($scope, $http) {
    $scope.users = [];
    $scope.newUser = {};
    $scope.selectedUser = {};
    $scope.searchText = '';
    $scope.buses = [];
    $scope.availableDays = ["segunda", "terça", "quarta", "quinta", "sexta", "sábado"];

    // Carregar usuários e ônibus
    $scope.loadUsers = function () {
        $http.get('/api/users.php')
            .then(function (response) {
                $scope.users = response.data;
            });
    };

    $http.get('/api/buses.php').then(function (response) {
        $scope.buses = response.data;
    });

    // Criar ou atualizar usuário
    $scope.saveUser = function () {
        $http.post('/api/users.php', $scope.newUser)
            .then(function (response) {
                alert(response.data.message);
                if (response.data.status === 'success') {
                    $('#userModal').modal('hide');
                    $scope.loadUsers();
                    $scope.newUser = {};
                }
            });
    };

    // Excluir usuário
    $scope.deleteUser = function (id) {
        if (confirm("Tem certeza que deseja excluir este usuário?")) {
            $http.delete('/api/users.php', { data: { id: id } })
                .then(function (response) {
                    alert(response.data.message);
                    $scope.loadUsers();
                });
        }
    };

    // Editar usuário
    $scope.editUser = function (user) {
        $scope.newUser = angular.copy(user);
        $('#userModal').modal('show');
    };

    // Gerenciar permissões
    $scope.managePermissions = function (user) {
        $scope.selectedUser = angular.copy(user);
        if (!$scope.selectedUser.schedule) $scope.selectedUser.schedule = [];
        $('#permissionModal').modal('show');
    };

    $scope.addSchedule = function () {
        $scope.selectedUser.schedule.push({ dia: '', bus_id: '' });
    };

    $scope.removeSchedule = function (index) {
        $scope.selectedUser.schedule.splice(index, 1);
    };

    $scope.savePermissions = function () {
        $http.post('/api/users.php', $scope.selectedUser)
            .then(function (response) {
                alert(response.data.message);
                $('#permissionModal').modal('hide');
                $scope.loadUsers();
            });
    };

    $scope.loadUsers();
});

