<?php
$pageTitle = "Relatório de Usuários"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

// Consulta os dados dos usuários e suas viagens, incluindo a localização
$stmt = $pdo->query("SELECT u.nome, t.data_viagem, t.status, t.mensagem, t.latitude, t.longitude
                     FROM trips t 
                     INNER JOIN users u ON t.user_id = u.id 
                     ORDER BY t.data_viagem DESC");
$relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);
include '../includes/header.php';
?>
<div class="container-xxl ml-4 mr-4 mt-4">
  <div class="row">
    <div class="col">
      <h2>Relatório de Usuários</h2>
      <div class="table-responsive">
        <table class="table table-bordered">
          <thead class="thead-dark">
            <tr>
              <th>Nome do Usuário</th>
              <th>Data da Viagem</th>
              <th>Status</th>
              <th>Mensagem</th>
              <th>Latitude</th>
              <th>Longitude</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($relatorios as $rel): ?>
              <tr>
                <td><?php echo htmlspecialchars($rel['nome']); ?></td>
                <td><?php echo htmlspecialchars($rel['data_viagem']); ?></td>
                <td><?php echo htmlspecialchars($rel['status']); ?></td>
                <td><?php echo htmlspecialchars($rel['mensagem']); ?></td>
                <td><?php echo htmlspecialchars($rel['latitude']); ?></td>
                <td><?php echo htmlspecialchars($rel['longitude']); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

