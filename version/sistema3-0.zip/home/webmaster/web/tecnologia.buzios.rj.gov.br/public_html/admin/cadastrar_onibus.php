<?php
$pageTitle = "Cadastro de Ônibus"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identificador  = trim($_POST['identificador']);
    $ponto_partida  = trim($_POST['ponto_partida']);
    $horario_ida    = trim($_POST['horario_ida']);
    $horario_volta  = trim($_POST['horario_volta']);
    $itinerario     = trim($_POST['itinerario']);

    if(empty($identificador) || empty($ponto_partida) || empty($horario_ida) || empty($horario_volta)) {
        $message = "Preencha os campos obrigatórios.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO buses (identificador, ponto_partida, horario_ida, horario_volta, itinerario) VALUES (:identificador, :ponto_partida, :horario_ida, :horario_volta, :itinerario)");
        if ($stmt->execute([
            'identificador' => $identificador,
            'ponto_partida' => $ponto_partida,
            'horario_ida'   => $horario_ida,
            'horario_volta' => $horario_volta,
            'itinerario'    => $itinerario
        ])) {
            $message = "Ônibus cadastrado com sucesso!";
        } else {
            $message = "Erro ao cadastrar ônibus.";
        }
    }
}

$busca = isset($_GET['busca']) ? trim($_GET['busca']) : '';
if ($busca != '') {
    $stmtList = $pdo->prepare("SELECT * FROM buses WHERE identificador LIKE :busca OR ponto_partida LIKE :busca ORDER BY id DESC");
    $stmtList->execute(['busca' => "%$busca%"]);
} else {
    $stmtList = $pdo->query("SELECT * FROM buses ORDER BY id DESC");
}
$buses = $stmtList->fetchAll(PDO::FETCH_ASSOC);
include '../includes/header.php';
?>
<div class="container mt-4">
  <!-- Card para cadastro de ônibus -->
  <div class="row justify-content-center mb-4">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Cadastrar Ônibus</h2>
        </div>
        <div class="card-body">
          <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
          <?php endif; ?>
          <form method="post" action="cadastrar_onibus.php">
            <div class="form-group">
              <label for="identificador">Identificador do Ônibus:</label>
              <input type="text" name="identificador" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="ponto_partida">Ponto de Partida:</label>
              <input type="text" name="ponto_partida" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="horario_ida">Horário de Ida:</label>
              <input type="time" name="horario_ida" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="horario_volta">Horário de Volta:</label>
              <input type="time" name="horario_volta" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="itinerario">Itinerário:</label>
              <textarea name="itinerario" class="form-control" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Cadastrar</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Card para pesquisa e listagem de ônibus -->
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h3>Ônibus Cadastrados</h3>
        </div>
        <div class="card-body">
          <form method="get" action="cadastrar_onibus.php" class="form-inline mb-3">
            <input type="text" name="busca" class="form-control mr-2" placeholder="Pesquisar por identificador ou ponto" value="<?php echo htmlspecialchars($busca); ?>">
            <button type="submit" class="btn btn-secondary">Pesquisar</button>
          </form>
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead class="thead-dark">
                <tr>
                  <th>ID</th>
                  <th>Identificador</th>
                  <th>Ponto de Partida</th>
                  <th>Horário de Ida</th>
                  <th>Horário de Volta</th>
                  <th>Itinerário</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                <?php if($buses): ?>
                  <?php foreach ($buses as $bus): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($bus['id']); ?></td>
                      <td><?php echo htmlspecialchars($bus['identificador']); ?></td>
                      <td><?php echo htmlspecialchars($bus['ponto_partida']); ?></td>
                      <td><?php echo htmlspecialchars($bus['horario_ida']); ?></td>
                      <td><?php echo htmlspecialchars($bus['horario_volta']); ?></td>
                      <td><?php echo htmlspecialchars($bus['itinerario']); ?></td>
                      <td>
                        <a href="editar_onibus.php?id=<?php echo $bus['id']; ?>" class="btn btn-sm btn-warning">Editar</a>
                        <a href="excluir_onibus.php?id=<?php echo $bus['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir este ônibus?');">Excluir</a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr>
                    <td colspan="7" class="text-center">Nenhum ônibus cadastrado.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

