<?php 
$pageTitle = "Editar Usuário"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

// Verifica se o ID do usuário foi passado via GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: cadastrar_usuario.php");
    exit;
}
$userId = intval($_GET['id']);

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome      = trim($_POST['nome']);
    $email     = trim($_POST['email']);
    $endereco  = trim($_POST['endereco']);
    $turno     = trim($_POST['turno']);
    // Campos adicionais
    $bairro    = trim($_POST['bairro']);
    $cpf       = trim($_POST['cpf']);
    $telefone  = trim($_POST['telefone']);
    $faculdade = trim($_POST['faculdade']);
    
    // Upload da foto
    $foto = "";
    if(isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK){
        $uploadDir = '../assets/uploads/';
        $foto = time() . '_' . basename($_FILES['foto']['name']);
        move_uploaded_file($_FILES['foto']['tmp_name'], $uploadDir . $foto);
    }
    
    // Agendamento: dias da semana e ônibus selecionado
    // $dias é um array com os dias selecionados, e $onibus_dia é um array associativo: dia => id do ônibus
    $dias = isset($_POST['dias']) ? $_POST['dias'] : [];
    $onibus_dia = isset($_POST['onibus_dia']) ? $_POST['onibus_dia'] : [];
    
    if (empty($nome) || empty($email)) {
        $message = "Preencha os campos obrigatórios (Nome e Email).";
    } else {
        try {
            // Inicia transação para atualização atômica
            $pdo->beginTransaction();
            
            // Atualiza os dados do usuário (se uma nova senha for fornecida, atualiza; senão, não atualiza o campo senha)
            if (!empty($_POST['senha'])) {
                $senha = trim($_POST['senha']);
                $senhaMD5 = md5($senha);
                $stmt = $pdo->prepare("UPDATE users 
                                       SET nome = :nome, email = :email, endereco = :endereco, turno = :turno, senha = :senha,
                                           bairro = :bairro, cpf = :cpf, telefone = :telefone, faculdade = :faculdade, foto = :foto
                                       WHERE id = :id");
                $params = [
                    'nome'      => $nome,
                    'email'     => $email,
                    'endereco'  => $endereco,
                    'turno'     => $turno,
                    'senha'     => $senhaMD5,
                    'bairro'    => $bairro,
                    'cpf'       => $cpf,
                    'telefone'  => $telefone,
                    'faculdade' => $faculdade,
                    'foto'      => $foto, // Se não for enviado novo arquivo, este valor pode ser vazio
                    'id'        => $userId
                ];
            } else {
                $stmt = $pdo->prepare("UPDATE users 
                                       SET nome = :nome, email = :email, endereco = :endereco, turno = :turno,
                                           bairro = :bairro, cpf = :cpf, telefone = :telefone, faculdade = :faculdade, foto = :foto
                                       WHERE id = :id");
                $params = [
                    'nome'      => $nome,
                    'email'     => $email,
                    'endereco'  => $endereco,
                    'turno'     => $turno,
                    'bairro'    => $bairro,
                    'cpf'       => $cpf,
                    'telefone'  => $telefone,
                    'faculdade' => $faculdade,
                    'foto'      => $foto, // Se não for enviado novo arquivo, este valor pode ser vazio
                    'id'        => $userId
                ];
            }
            $stmt->execute($params);
            
            // Atualiza os agendamentos: primeiro, remove os existentes para este usuário
            $stmtDelete = $pdo->prepare("DELETE FROM user_schedule WHERE user_id = :user_id");
            $stmtDelete->execute(['user_id' => $userId]);
            
            // Insere os novos agendamentos
            foreach ($dias as $dia) {
                $dia = trim($dia);
                if (isset($onibus_dia[$dia]) && !empty($onibus_dia[$dia])) {
                    $stmtSched = $pdo->prepare("INSERT INTO user_schedule (user_id, dia_semana, bus_id) VALUES (:user_id, :dia, :bus_id)");
                    $stmtSched->execute([
                        'user_id' => $userId,
                        'dia'     => $dia,
                        'bus_id'  => $onibus_dia[$dia]
                    ]);
                }
            }
            
            $pdo->commit();
            $message = "Usuário atualizado com sucesso!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "Erro ao atualizar usuário: " . $e->getMessage();
        }
    }
}

// Recupera os dados atuais do usuário
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    echo "Usuário não encontrado.";
    exit;
}

// Para o agendamento, recupere os dias já cadastrados para este usuário como um array chave => valor
$stmtSched = $pdo->prepare("SELECT dia_semana, bus_id FROM user_schedule WHERE user_id = :user_id");
$stmtSched->execute(['user_id' => $userId]);
$agendamentos = $stmtSched->fetchAll(PDO::FETCH_KEY_PAIR);

// Obtenha a lista de ônibus para o dropdown dos agendamentos
$stmtBuses = $pdo->query("SELECT id, identificador FROM buses ORDER BY identificador ASC");
$buses = $stmtBuses->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Editar Usuário</h2>
        </div>
        <div class="card-body">
          <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
          <?php endif; ?>
          <form method="post" action="editar_usuario.php?id=<?php echo $userId; ?>" enctype="multipart/form-data">
            <div class="form-group">
              <label for="nome">Nome:</label>
              <input type="text" name="nome" class="form-control" value="<?php echo htmlspecialchars($user['nome']); ?>" required>
            </div>
            <div class="form-group">
              <label for="email">Email:</label>
              <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
              <label for="endereco">Endereço:</label>
              <input type="text" name="endereco" class="form-control" value="<?php echo htmlspecialchars($user['endereco']); ?>">
            </div>
            <div class="form-group">
              <label for="turno">Turno:</label>
              <select name="turno" class="form-control" required>
                <option value="manha" <?php echo ($user['turno'] == 'manha' ? 'selected' : ''); ?>>Manhã</option>
                <option value="tarde" <?php echo ($user['turno'] == 'tarde' ? 'selected' : ''); ?>>Tarde</option>
                <option value="noite" <?php echo ($user['turno'] == 'noite' ? 'selected' : ''); ?>>Noite</option>
              </select>
            </div>
            <!-- Campos adicionais -->
            <div class="form-group">
              <label for="bairro">Bairro:</label>
              <input type="text" name="bairro" class="form-control" value="<?php echo htmlspecialchars($user['bairro']); ?>">
            </div>
            <div class="form-group">
              <label for="cpf">CPF:</label>
              <input type="text" name="cpf" class="form-control" value="<?php echo htmlspecialchars($user['cpf']); ?>">
            </div>
            <div class="form-group">
              <label for="telefone">Telefone:</label>
              <input type="text" name="telefone" class="form-control" value="<?php echo htmlspecialchars($user['telefone']); ?>">
            </div>
            <div class="form-group">
              <label for="faculdade">Faculdade:</label>
              <input type="text" name="faculdade" class="form-control" value="<?php echo htmlspecialchars($user['faculdade']); ?>">
            </div>
            <div class="form-group">
              <label for="foto">Foto:</label>
              <input type="file" name="foto" class="form-control-file">
            </div>
            <!-- Agendamento: dias da semana com seleção de ônibus -->
            <div class="form-group">
              <label>Dias de Atendimento:</label>
              <?php
              $diasSemana = ["segunda" => "Segunda", "terca" => "Terça", "quarta" => "Quarta", "quinta" => "Quinta", "sexta" => "Sexta", "sabado" => "Sábado"];
              foreach ($diasSemana as $diaKey => $diaNome):
                $checked = isset($agendamentos[$diaKey]) ? "checked" : "";
                $selectedBus = isset($agendamentos[$diaKey]) ? $agendamentos[$diaKey] : "";
              ?>
                <div class="form-row align-items-center mb-2">
                  <div class="col-auto">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="dias[]" value="<?php echo $diaKey; ?>" id="dia_<?php echo $diaKey; ?>" <?php echo $checked; ?>>
                      <label class="form-check-label" for="dia_<?php echo $diaKey; ?>"><?php echo $diaNome; ?></label>
                    </div>
                  </div>
                  <div class="col">
                    <select class="form-control" name="onibus_dia[<?php echo $diaKey; ?>]">
                      <option value="">Selecione o Ônibus</option>
                      <?php foreach ($buses as $bus): ?>
                        <option value="<?php echo $bus['id']; ?>" <?php echo ($selectedBus == $bus['id'] ? "selected" : ""); ?>>
                          <?php echo htmlspecialchars($bus['identificador']); ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
            <div class="form-group">
              <label for="senha">Nova Senha (deixe em branco para manter a atual):</label>
              <input type="password" name="senha" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Atualizar Usuário</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

