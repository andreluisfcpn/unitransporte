<?php
$pageTitle = "Editar Ônibus"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

// Verifica se o ID do ônibus foi passado via GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: cadastrar_onibus.php");
    exit;
}
$busId = intval($_GET['id']);

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identificador = trim($_POST['identificador']);
    $ponto_partida = trim($_POST['ponto_partida']);
    $horario_ida   = trim($_POST['horario_ida']);
    $horario_volta = trim($_POST['horario_volta']);
    $itinerario    = trim($_POST['itinerario']);

    if(empty($identificador) || empty($ponto_partida) || empty($horario_ida) || empty($horario_volta)) {
        $message = "Preencha os campos obrigatórios.";
    } else {
        $stmt = $pdo->prepare("UPDATE buses 
                               SET identificador = :identificador, 
                                   ponto_partida = :ponto_partida, 
                                   horario_ida = :horario_ida, 
                                   horario_volta = :horario_volta, 
                                   itinerario = :itinerario 
                               WHERE id = :id");
        if ($stmt->execute([
            'identificador' => $identificador,
            'ponto_partida' => $ponto_partida,
            'horario_ida'   => $horario_ida,
            'horario_volta' => $horario_volta,
            'itinerario'    => $itinerario,
            'id'            => $busId
        ])) {
            $message = "Ônibus atualizado com sucesso!";
        } else {
            $message = "Erro ao atualizar ônibus.";
        }
    }
}

// Recupera os dados atuais do ônibus
$stmt = $pdo->prepare("SELECT * FROM buses WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $busId]);
$bus = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$bus) {
    echo "Ônibus não encontrado.";
    exit;
}

include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Editar Ônibus</h2>
        </div>
        <div class="card-body">
          <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
          <?php endif; ?>
          <form method="post" action="editar_onibus.php?id=<?php echo $busId; ?>">
            <div class="form-group">
              <label for="identificador">Identificador do Ônibus:</label>
              <input type="text" name="identificador" class="form-control" value="<?php echo htmlspecialchars($bus['identificador']); ?>" required>
            </div>
            <div class="form-group">
              <label for="ponto_partida">Ponto de Partida:</label>
              <input type="text" name="ponto_partida" class="form-control" value="<?php echo htmlspecialchars($bus['ponto_partida']); ?>" required>
            </div>
            <div class="form-group">
              <label for="horario_ida">Horário de Ida:</label>
              <input type="time" name="horario_ida" class="form-control" value="<?php echo htmlspecialchars($bus['horario_ida']); ?>" required>
            </div>
            <div class="form-group">
              <label for="horario_volta">Horário de Volta:</label>
              <input type="time" name="horario_volta" class="form-control" value="<?php echo htmlspecialchars($bus['horario_volta']); ?>" required>
            </div>
            <div class="form-group">
              <label for="itinerario">Itinerário:</label>
              <textarea name="itinerario" class="form-control" rows="3"><?php echo htmlspecialchars($bus['itinerario']); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Atualizar Ônibus</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

