<?php
// motorista/verificar_acesso.php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'motorista') {
    http_response_code(403);
    echo json_encode(['status' => 'erro', 'mensagem' => 'Acesso negado.']);
    exit;
}

if (!isset($_POST['userId']) || !isset($_POST['busId'])) {
    echo json_encode(['status' => 'erro', 'mensagem' => 'Dados insuficientes.']);
    exit;
}

$userId = intval($_POST['userId']);
$busId  = intval($_POST['busId']);

// Obter o dia da semana atual em português (segunda, terca, ...)
$diaSemanaIngles = date('l'); // ex: Monday, Tuesday, ...
$mapaDias = [
    'Monday'    => 'segunda',
    'Tuesday'   => 'terca',
    'Wednesday' => 'quarta',
    'Thursday'  => 'quinta',
    'Friday'    => 'sexta',
    'Saturday'  => 'sabado',
    'Sunday'    => 'domingo'
];
$diaAtual = isset($mapaDias[$diaSemanaIngles]) ? $mapaDias[$diaSemanaIngles] : strtolower($diaSemanaIngles);

$stmt = $pdo->prepare("SELECT COUNT(*) FROM user_schedule WHERE user_id = :user_id AND dia_semana = :dia AND bus_id = :bus_id");
$stmt->execute([
    'user_id' => $userId,
    'dia'     => $diaAtual,
    'bus_id'  => $busId
]);
$count = $stmt->fetchColumn();

if ($count > 0) {
    echo json_encode(['status' => 'autorizado']);
} else {
    echo json_encode(['status' => 'nao_autorizado']);
}
?>
