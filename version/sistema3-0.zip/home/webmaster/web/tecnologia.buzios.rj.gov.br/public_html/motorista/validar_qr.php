<?php 
$pageTitle = "Validação de QR Code"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('motorista');

// Obtenha a lista de ônibus para o dropdown
$stmtBuses = $pdo->query("SELECT id, identificador FROM buses ORDER BY identificador ASC");
$buses = $stmtBuses->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Validação de QR Code</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    #reader {
      width: 100%;
      max-width: 500px;
      height: 100%;
      margin: 20px auto;
      background-color: #000;
      border: 1px solid #ccc;
    }
    .permissao-ok { color: green; }
    .permissao-neg { color: red; }
  </style>
</head>
<body>
  <?php include '../includes/header.php'; ?>
  <div class="container mt-4">
    <div class="row justify-content-center mb-3">
      <div class="col-md-6">
        <label for="busSelect">Selecione o Ônibus em que está:</label>
        <select id="busSelect" class="form-control">
          <option value="">Selecione...</option>
          <?php foreach($buses as $bus): ?>
            <option value="<?php echo $bus['id']; ?>"><?php echo htmlspecialchars($bus['identificador']); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="row text-center">
      <div class="col">
        <h2 class="mt-4">Scanner de QR Code</h2>
        <p>Aponte a câmera para o QR Code fixo do usuário.</p>
        <div id="reader"></div>
      </div>
    </div>
  </div>
  
  <!-- Modal para exibir os dados do usuário -->
  <div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="userModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 id="userModalLabel" class="modal-title">Dados do Usuário</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Fechar" id="closeModalBtn">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" id="modalUserInfo">
          <!-- Os dados do usuário serão exibidos aqui -->
        </div>
        <div class="modal-footer" id="modalFooter">
          <!-- Os botões serão ajustados conforme a permissão -->
          <button type="button" id="recuseBtn" class="btn btn-danger">Recusar</button>
          <button type="button" id="confirmBtn" class="btn btn-success">Confirmar</button>
        </div>
      </div>
    </div>
  </div>
  
  <?php include '../includes/footer.php'; ?>
  
  <!-- Scripts: jQuery, Bootstrap, html5-qrcode -->
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
  <script>
    let currentUserId = null;
    let html5QrCode;
    let currentLatitude = "";
    let currentLongitude = "";
    
    // Atualiza a posição ao carregar a página (para minimizar atrasos na leitura)
    function atualizarPosicao() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
          currentLatitude = position.coords.latitude;
          currentLongitude = position.coords.longitude;
        }, function(error) {
          console.error("Erro ao obter localização:", error);
          currentLatitude = "";
          currentLongitude = "";
        });
      } else {
        console.error("Geolocalização não suportada.");
      }
    }
    atualizarPosicao();
    
    // Função para mapear getDay() para nomes de dias em português (minúsculas)
    function getDiaSemana() {
      const dias = ["domingo", "segunda", "terca", "quarta", "quinta", "sexta", "sabado"];
      return dias[new Date().getDay()];
    }
    
    function onScanSuccess(decodedText, decodedResult) {
      console.log("QR Code detectado:", decodedText);
      html5QrCode.stop().then(() => {
        // Atualiza a posição novamente antes de processar o QR Code
        atualizarPosicao();
        processQRCode(decodedText);
      }).catch(err => {
        console.error("Erro ao parar scanner:", err);
      });
    }
    
    function onScanFailure(error) {
      console.warn("Falha na leitura do QR Code: " + error);
    }
    
    function startScanner() {
      $("#userModal").modal('hide');
      currentUserId = null;
      const config = { fps: 10, qrbox: 250 };
      html5QrCode.start({ facingMode: "environment" }, config, onScanSuccess, onScanFailure)
      .catch(err => {
        console.error("Erro ao iniciar scanner:", err);
        alert("Erro ao iniciar scanner: " + err);
      });
    }
    
    function processQRCode(decodedText) {
      $.ajax({
        url: 'buscar_usuario.php',
        method: 'POST',
        dataType: 'json',
        data: { qrData: decodedText },
        success: function(response) {
          if(response.status === 'sucesso') {
            const user = response.data;
            currentUserId = user.id;
            let html = "<div class='d-flex align-items-center'>";
            if(user.foto){
              html += "<img src='/assets/uploads/" + user.foto + "' alt='Foto' style='height:80px; width:80px; object-fit:cover; margin-right:15px; border-radius:50%;'>";
            } else {
              html += "<img src='/assets/img/default_user.png' alt='Sem Foto' style='height:80px; width:80px; object-fit:cover; margin-right:15px; border-radius:50%;'>";
            }
            html += "<div>";
            html += "<p><strong>Nome:</strong> " + user.nome + "</p>";
            html += "<p><strong>Email:</strong> " + user.email + "</p>";
            html += "<p><strong>CPF:</strong> " + (user.cpf ? user.cpf : "Não informado") + "</p>";
            html += "</div></div>";
            
            // Verifica se o dia atual está agendado para o usuário e se o ônibus selecionado bate
            let diaAtual = getDiaSemana();
            let schedule = user.schedule; // Ex: { "segunda": 3, "terca": 5, ... }
            let busSelecionado = $("#busSelect").val();
            let permitido = false;
            let mensagemPermissao = "";
            if(schedule && schedule[diaAtual]) {
              if(busSelecionado && parseInt(busSelecionado) === parseInt(schedule[diaAtual])) {
                permitido = true;
              }
            }
            if(permitido) {
              mensagemPermissao = "<p class='permissao-ok'><strong>Acesso permitido.</strong></p>";
              $("#recuseBtn").hide();
            } else {
              mensagemPermissao = "<p class='permissao-neg'><strong>Fora dos dias permitidos.</strong></p>";
              $("#recuseBtn").show();
            }
            $("#modalUserInfo").html(mensagemPermissao + html);
            $("#userModal").modal('show');
          } else {
            alert("Usuário não encontrado ou QR Code inválido.");
            startScanner();
          }
        },
        error: function(xhr, status, error) {
          console.error("Erro ao buscar usuário:", error);
          alert("Erro na comunicação com o servidor.");
          startScanner();
        }
      });
    }
    
    $("#recuseBtn").click(function() {
    let busId = $("#busSelect").val();
    if (!busId) {
        alert("Por favor, selecione o ônibus em que está.");
        return;
    }

    $.ajax({
        url: 'confirmar_viagem.php',
        method: 'POST',
        dataType: 'json',
        data: { 
            userId: currentUserId, 
            busId: busId, 
            action: 'recusar',
            latitude: currentLatitude,
            longitude: currentLongitude
        },
        success: function(response) {
            console.log("Resposta do servidor:", response); // Verifica a resposta
            if (response.status === 'sucesso') {
                alert("Viagem registrada como recusada.");
            } else {
                alert("Erro: " + response.mensagem);
            }
            currentUserId = null;
            $("#userModal").modal('hide');
            setTimeout(startScanner, 1000);
        },
        error: function(xhr, status, error) {
            console.error("Erro AJAX:", xhr.responseText); // Exibe a resposta do erro
            alert("Erro na comunicação com o servidor.");
            setTimeout(startScanner, 1000);
        }
    });
});

    
    $("#confirmBtn").click(function(){
      let busId = $("#busSelect").val();
      if(!busId) {
        alert("Por favor, selecione o ônibus em que está.");
        return;
      }
      // Se o botão Recusar estiver visível, a ação será 'excecao', caso contrário 'confirmar'
      let actionEnvio = ($("#recuseBtn").is(":visible")) ? 'excecao' : 'confirmar';
      $.ajax({
        url: 'confirmar_viagem.php',
        method: 'POST',
        dataType: 'json',
        data: { 
          userId: currentUserId, 
          busId: busId, 
          action: actionEnvio,
          latitude: currentLatitude,
          longitude: currentLongitude
        },
        success: function(response) {
          if(response.status === 'sucesso'){
            alert("Viagem registrada: " + response.mensagem);
          } else {
            alert("Erro: " + response.mensagem);
          }
          currentUserId = null;
          $("#userModal").modal('hide');
          setTimeout(startScanner, 1000);
        },
        error: function(xhr, status, error) {
          console.error("Erro ao confirmar viagem:", error);
          alert("Erro na comunicação com o servidor.");
          setTimeout(startScanner, 1000);
        }
      });
    });
    
    $("#closeModalBtn").click(function(){
      currentUserId = null;
      setTimeout(startScanner, 1000);
    });
    
    $(document).ready(function(){
      html5QrCode = new Html5Qrcode("reader");
      Html5Qrcode.getCameras().then(cameras => {
        if(cameras && cameras.length) {
          startScanner();
        } else {
          alert("Nenhuma câmera encontrada.");
        }
      }).catch(err => {
        console.error("Erro ao obter câmeras:", err);
        alert("Erro ao obter câmeras: " + err);
      });
    });
  </script>
</body>
</html>

