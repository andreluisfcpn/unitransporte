<?php 
$pageTitle = "Início"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('motorista');
include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row mb-3">
    <div class="col">
      <h2 class="text-center">Dashboard do Motorista</h2>
    </div>
  </div>
  <div class="row">
    <!-- Card para "Validar QR Code" -->
    <div class="col-md-6 col-sm-12 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Validar QR Code</h5>
          <p class="card-text">Utilize o scanner para validar a passagem dos usuários.</p>
          <a href="validar_qr.php" class="btn btn-primary">Validar QR Code</a>
        </div>
      </div>
    </div>
    <!-- Card para "Histórico de Validações" -->
    <div class="col-md-6 col-sm-12 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Histórico de Validações</h5>
          <p class="card-text">Consulte as validações realizadas.</p>
          <a href="historico_validacoes.php" class="btn btn-primary">Ver Histórico</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

