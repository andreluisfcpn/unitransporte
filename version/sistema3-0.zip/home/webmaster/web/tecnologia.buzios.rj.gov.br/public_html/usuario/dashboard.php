<?php 
// usuario/dashboard.php
$pageTitle = "Início"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('usuario');
include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row mb-3">
    <div class="col">
      <h2 class="text-center">Dashboard do Usuário</h2>
    </div>
  </div>
  <div class="row">
    <!-- Card para "Meu Perfil" -->
    <div class="col-md-4 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Meu Perfil</h5>
          <p class="card-text">Visualize e atualize seus dados pessoais.</p>
          <a href="perfil.php" class="btn btn-primary">Acessar Perfil</a>
        </div>
      </div>
    </div>
    <!-- Card para "Gerar QR Code" -->
    <div class="col-md-4 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Gerar QR Code</h5>
          <p class="card-text">Visualize e imprima seu QR Code fixo.</p>
          <a href="gerar_qr.php" class="btn btn-primary">Gerar QR Code</a>
        </div>
      </div>
    </div>
    <!-- Card para "Histórico de Viagens" -->
    <div class="col-md-4 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Histórico de Viagens</h5>
          <p class="card-text">Consulte as suas viagens realizadas.</p>
          <a href="historico_viagens.php" class="btn btn-primary">Ver Histórico</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

