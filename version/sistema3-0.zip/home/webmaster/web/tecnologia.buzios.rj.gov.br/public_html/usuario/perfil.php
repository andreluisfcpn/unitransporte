<?php 
// usuario/perfil.php
$pageTitle = "Perfil"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('usuario');

// Atualiza apenas os campos editáveis: email, endereço e telefone
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']);
    $endereco = trim($_POST['endereco']);
    $telefone = trim($_POST['telefone']);

    if(empty($email) || empty($endereco) || empty($telefone)) {
        $message = "Email, Endereço e Telefone são obrigatórios.";
    } else {
        $stmt = $pdo->prepare("UPDATE users SET email = :email, endereco = :endereco, telefone = :telefone WHERE id = :id");
        if ($stmt->execute([
            'email'    => $email,
            'endereco' => $endereco,
            'telefone' => $telefone,
            'id'       => $_SESSION['user']['id']
        ])) {
            $message = "Perfil atualizado com sucesso!";
            $_SESSION['user']['email']    = $email;
            $_SESSION['user']['endereco'] = $endereco;
            $_SESSION['user']['telefone'] = $telefone;
        } else {
            $message = "Erro ao atualizar perfil.";
        }
    }
}

// Recupera os dados do usuário
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $_SESSION['user']['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Recupera o agendamento do usuário (dias de atendimento e ônibus selecionado)
$stmtSchedule = $pdo->prepare("SELECT us.dia_semana, b.identificador 
                               FROM user_schedule us 
                               INNER JOIN buses b ON us.bus_id = b.id 
                               WHERE us.user_id = :user_id");
$stmtSchedule->execute(['user_id' => $_SESSION['user']['id']]);
$schedule = $stmtSchedule->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include '../includes/header.php'; ?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <h2>Meu Perfil</h2>
      <?php if($message): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
      <?php endif; ?>
      <form method="post" action="perfil.php" enctype="multipart/form-data">
        <div class="form-group">
          <label for="nome">Nome:</label>
          <input type="text" name="nome" class="form-control" value="<?php echo htmlspecialchars($user['nome']); ?>" disabled>
        </div>
        <div class="form-group">
          <label for="email">Email:</label>
          <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>">
        </div>
        <div class="form-group">
          <label for="endereco">Endereço:</label>
          <input type="text" name="endereco" class="form-control" value="<?php echo htmlspecialchars($user['endereco']); ?>">
        </div>
        <div class="form-group">
          <label for="telefone">Telefone:</label>
          <input type="text" name="telefone" id="telefone" class="form-control" value="<?php echo htmlspecialchars($user['telefone']); ?>">
        </div>
        <div class="form-group">
          <label for="bairro">Bairro:</label>
          <input type="text" name="bairro" class="form-control" value="<?php echo htmlspecialchars($user['bairro']); ?>" disabled>
        </div>
        <div class="form-group">
          <label for="cpf">CPF:</label>
          <input type="text" name="cpf" class="form-control" value="<?php echo htmlspecialchars($user['cpf']); ?>" disabled>
        </div>
        <div class="form-group">
          <label for="faculdade">Faculdade:</label>
          <input type="text" name="faculdade" class="form-control" value="<?php echo htmlspecialchars($user['faculdade']); ?>" disabled>
        </div>
        <div class="form-group">
          <label for="foto">Foto:</label>
          <?php if(!empty($user['foto'])): ?>
            <br>
            <img src="/assets/uploads/<?php echo htmlspecialchars($user['foto']); ?>" alt="Foto" style="height:100px;">
          <?php else: ?>
            <p>Sem foto</p>
          <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Atualizar Perfil</button>
      </form>
<!-- Seção de Viagens Permitidas -->
<div class="mt-5">
  <h3>Viagens permitidas</h3>
  <?php if($schedule): ?>
    <ul class="list-group">
      <?php foreach($schedule as $sch): ?>
        <li class="list-group-item">
          <strong><?php echo ucfirst($sch['dia_semana']); ?>:</strong> Ônibus <?php echo htmlspecialchars($sch['identificador']); ?>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <p>Nenhuma viagem foi permitida.</p>
  <?php endif; ?>
</div>
    </div>
  </div>
</div>
<!-- Máscara para o campo de telefone em JavaScript simples -->
<script>
  function formatPhone(value) {
      // Remove tudo que não é dígito
      value = value.replace(/\D/g, '');
      // Limita a 11 dígitos
      if (value.length > 11) {
          value = value.substring(0,11);
      }
      // Formata de acordo com (xx) xxxxx-xxxx
      if (value.length <= 2) {
          return '(' + value;
      } else if (value.length <= 7) {
          return '(' + value.substring(0,2) + ') ' + value.substring(2);
      } else {
          return '(' + value.substring(0,2) + ') ' + value.substring(2,7) + '-' + value.substring(7);
      }
  }
  document.getElementById('telefone').addEventListener('input', function(e) {
      e.target.value = formatPhone(e.target.value);
  });
</script>
<?php include '../includes/footer.php'; ?>

