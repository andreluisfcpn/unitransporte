<?php  
$pageTitle = "Início"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');
include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row mb-3">
    <div class="col">
      <h2 class="text-center">Dashboard do Administrador</h2>
    </div>
  </div>
  <div class="row">
    <!-- Card para Cadastro de Usuário -->
    <div class="col-md-4 col-sm-6 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Cadastro de Usuário</h5>
          <p class="card-text">Registrar novos usuários do sistema.</p>
          <a href="cadastrar_usuario.php" class="btn btn-primary">Cadastro de Usuário</a>
        </div>
      </div>
    </div>
    <!-- Card para Cadastro de Motorista -->
    <div class="col-md-4 col-sm-6 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Cadastro de Motorista</h5>
          <p class="card-text">Registrar novos motoristas do sistema.</p>
          <a href="cadastrar_motorista.php" class="btn btn-primary">Cadastro de Motorista</a>
        </div>
      </div>
    </div>
    <!-- Card para Cadastro de Ônibus -->
    <div class="col-md-4 col-sm-6 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Cadastro de Ônibus</h5>
          <p class="card-text">Cadastrar novos ônibus com seus detalhes.</p>
          <a href="cadastrar_onibus.php" class="btn btn-primary">Cadastro de Ônibus</a>
        </div>
      </div>
    </div>
    <!-- Card para Relatório de Usuários -->
    <div class="col-md-4 col-sm-6 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Relatório de Usuários</h5>
          <p class="card-text">Visualizar relatórios de viagens dos usuários do sistema.</p>
          <a href="relatorio_usuarios.php" class="btn btn-primary">Ver Relatório</a>
        </div>
      </div>
    </div>
    <!-- Card para Relatório de Motoristas -->
    <div class="col-md-4 col-sm-6 mb-3">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Relatório de Motoristas</h5>
          <p class="card-text">Visualizar relatórios de validações realizadas pelos motoristas.</p>
          <a href="relatorio_motoristas.php" class="btn btn-primary">Ver Relatório</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

