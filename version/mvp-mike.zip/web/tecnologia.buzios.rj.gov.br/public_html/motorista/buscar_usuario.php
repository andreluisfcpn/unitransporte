<?php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'motorista') {
  http_response_code(403);
  echo json_encode(['status' => 'erro', 'mensagem' => 'Acesso negado.']);
  exit;
}

if (!isset($_POST['qrData'])) {
  echo json_encode(['status' => 'erro', 'mensagem' => 'QR Data não fornecido.']);
  exit;
}

$qrDataEncoded = trim($_POST['qrData']);
$qrDataDecoded = rawurldecode($qrDataEncoded);
$userData = json_decode($qrDataDecoded, true);

if (!$userData || !isset($userData['id'])) {
  echo json_encode(['status' => 'erro', 'mensagem' => 'QR Code inválido.']);
  exit;
}

$userId = intval($userData['id']);

$stmt = $pdo->prepare("SELECT id, nome, email, turno, cpf, foto FROM users WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
  // Busque os agendamentos (schedule) do usuário
  $stmtSched = $pdo->prepare("SELECT dia_semana, bus_id FROM user_schedule WHERE user_id = :id");
  $stmtSched->execute(['id' => $userId]);
  $schedule = $stmtSched->fetchAll(PDO::FETCH_KEY_PAIR);
  $user['schedule'] = $schedule;
  
  echo json_encode(['status' => 'sucesso', 'data' => $user]);
} else {
  echo json_encode(['status' => 'erro', 'mensagem' => 'Usuário não encontrado.']);
}
?>

