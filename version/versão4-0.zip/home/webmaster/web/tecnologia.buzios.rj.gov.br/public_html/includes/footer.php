<!-- includes/footer.php -->
<footer class="bg-light text-center text-dark mt-4 p-3">
  <img src="/assets/img/buzios_logo.png" alt="Búzios Logo" style="height:50px;">
  <p class="mt-2 mb-0">Prefeitura de Armação dos Búzios - 2025</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

