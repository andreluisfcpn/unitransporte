<?php
// /admin/api/update_motorista.php
require_once '../../config.php';
require_once '../../includes/auth.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(['message' => 'Método não permitido']);
  exit;
}

$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
if ($user_id <= 0) {
  http_response_code(400);
  echo json_encode(['message' => 'ID do motorista inválido']);
  exit;
}

$nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$endereco = isset($_POST['endereco']) ? trim($_POST['endereco']) : '';
$cpf = isset($_POST['cpf']) ? trim($_POST['cpf']) : '';
$telefone = isset($_POST['telefone']) ? trim($_POST['telefone']) : '';
$senha = isset($_POST['senha']) ? trim($_POST['senha']) : '';

try {
    $params = [
       'nome' => $nome,
       'email' => $email,
       'endereco' => $endereco,
       'cpf' => $cpf,
       'telefone' => $telefone,
       'user_id' => $user_id
    ];
    $query = "UPDATE users SET nome = :nome, email = :email, endereco = :endereco, cpf = :cpf, telefone = :telefone";
    if (!empty($senha)) {
       $query .= ", senha = :senha";
       $params['senha'] = md5($senha);
    }
    if(isset($_FILES['fotoFile']) && $_FILES['fotoFile']['error'] === UPLOAD_ERR_OK){
       $uploadDir = '../../assets/uploads/';
       $fotoName = time() . '_' . basename($_FILES['fotoFile']['name']);
       if(!move_uploaded_file($_FILES['fotoFile']['tmp_name'], $uploadDir . $fotoName)){
           throw new Exception("Falha no upload da nova foto.");
       }
       $fotoPath = '/assets/uploads/' . $fotoName;
       $query .= ", foto = :foto";
       $params['foto'] = $fotoPath;
    }
    $query .= " WHERE id = :user_id AND role = 'motorista'";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    echo json_encode(['message' => 'Motorista atualizado com sucesso']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['message' => 'Erro ao atualizar motorista: ' . $e->getMessage()]);
}
?>

