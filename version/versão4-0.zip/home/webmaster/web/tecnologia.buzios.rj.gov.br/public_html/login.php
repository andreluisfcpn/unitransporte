<?php
// login.php
session_start();
require_once 'config.php';

$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);

    if (empty($email) || empty($senha)) {
        $error = "Preencha todos os campos.";
    } else {
        $query = "SELECT * FROM users WHERE email = :email LIMIT 1";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $senhaMD5 = md5($senha);
            if ($senhaMD5 === $user['senha']) {
                $_SESSION['user'] = [
                    'id'    => $user['id'],
                    'nome'  => $user['nome'],
                    'email' => $user['email'],
                    'role'  => $user['role'],
                    'turno' => $user['turno']
                ];
                switch ($user['role']) {
                    case 'admin':
                        header("Location: /admin/dashboard.php");
                        break;
                    case 'motorista':
                        header("Location: /motorista/dashboard.php");
                        break;
                    case 'usuario':
                        header("Location: /usuario/dashboard.php");
                        break;
                    default:
                        header("Location: /login.php");
                        break;
                }
                exit;
            }
        }
        $error = "Email ou senha incorretos.";
    }
}
?>
<?php include 'includes/header.php'; ?>
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2 class="mb-0">Login</h2>
        </div>
        <div class="card-body">
          <?php if($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
          <?php endif; ?>
          <form method="post" action="login.php">
            <div class="form-group">
              <label for="email">Email:</label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="senha">Senha:</label>
              <input type="password" name="senha" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Entrar</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>

