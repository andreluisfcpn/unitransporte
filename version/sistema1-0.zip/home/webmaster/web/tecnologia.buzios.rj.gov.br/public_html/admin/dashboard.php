<?php
// admin/dashboard.php
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');
?>
<?php include '../includes/header.php'; ?>
<div class="row">
    <div class="col">
        <h2>Dashboard do Administrador</h2>
        <ul class="list-group">
            <li class="list-group-item"><a href="cadastrar_usuario.php">Cadastrar Usuário</a></li>
            <li class="list-group-item"><a href="cadastrar_motorista.php">Cadastrar Motorista</a></li>
            <li class="list-group-item"><a href="cadastrar_onibus.php">Cadastrar Ônibus</a></li>
            <li class="list-group-item"><a href="relatorio_usuarios.php">Relatório de Usuários</a></li>
            <li class="list-group-item"><a href="relatorio_motoristas.php">Relatório de Motoristas</a></li>
        </ul>
    </div>
</div>
<?php include '../includes/footer.php'; ?>
