<?php
// admin/relatorio_motoristas.php
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

$stmt = $pdo->query("SELECT m.nome AS motorista, t.data_viagem, t.status, t.mensagem 
                     FROM trips t 
                     INNER JOIN users m ON t.motorista_id = m.id 
                     ORDER BY t.data_viagem DESC");
$relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include '../includes/header.php'; ?>
<div class="row">
    <div class="col">
        <h2>Relatório de Motoristas</h2>
        <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Nome do Motorista</th>
                    <th>Data da Viagem</th>
                    <th>Status</th>
                    <th>Mensagem</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($relatorios as $rel): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($rel['motorista']); ?></td>
                        <td><?php echo htmlspecialchars($rel['data_viagem']); ?></td>
                        <td><?php echo htmlspecialchars($rel['status']); ?></td>
                        <td><?php echo htmlspecialchars($rel['mensagem']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<?php include '../includes/footer.php'; ?>

