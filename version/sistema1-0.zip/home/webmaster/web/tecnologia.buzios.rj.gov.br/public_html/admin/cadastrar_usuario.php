<?php
// admin/cadastrar_usuario.php
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = trim($_POST['nome']);
    $email    = trim($_POST['email']);
    $senha    = trim($_POST['senha']);
    $endereco = trim($_POST['endereco']);
    $turno    = $_POST['turno'];

    if(empty($nome) || empty($email) || empty($senha)) {
        $message = "Preencha os campos obrigatórios.";
    } else {
        $senhaMD5 = md5($senha);
        $stmt = $pdo->prepare("INSERT INTO users (nome, email, senha, endereco, role, turno) VALUES (:nome, :email, :senha, :endereco, 'usuario', :turno)");
        if ($stmt->execute([
            'nome'     => $nome,
            'email'    => $email,
            'senha'    => $senhaMD5,
            'endereco' => $endereco,
            'turno'    => $turno
        ])) {
            $message = "Usuário cadastrado com sucesso!";
        } else {
            $message = "Erro ao cadastrar usuário.";
        }
    }
}

// Área de pesquisa e listagem de usuários (role = 'usuario')
$busca = isset($_GET['busca']) ? trim($_GET['busca']) : '';
if ($busca != '') {
    $stmtList = $pdo->prepare("SELECT * FROM users WHERE role = 'usuario' AND (nome LIKE :busca OR email LIKE :busca) ORDER BY id DESC");
    $stmtList->execute(['busca' => "%$busca%"]);
} else {
    $stmtList = $pdo->query("SELECT * FROM users WHERE role = 'usuario' ORDER BY id DESC");
}
$usuarios = $stmtList->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include '../includes/header.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <h2>Cadastrar Usuário</h2>
        <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <form method="post" action="cadastrar_usuario.php">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="password" name="senha" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="endereco">Endereço:</label>
                <input type="text" name="endereco" class="form-control">
            </div>
            <div class="form-group">
                <label for="turno">Turno:</label>
                <select name="turno" class="form-control" required>
                    <option value="manha">Manhã</option>
                    <option value="tarde">Tarde</option>
                    <option value="noite">Noite</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
        
        <!-- Área de pesquisa e listagem -->
        <hr>
        <h3 class="mt-4">Usuários Cadastrados</h3>
        <form method="get" action="cadastrar_usuario.php" class="form-inline mb-3">
            <input type="text" name="busca" class="form-control mr-2" placeholder="Pesquisar por nome ou email" value="<?php echo htmlspecialchars($busca); ?>">
            <button type="submit" class="btn btn-secondary">Pesquisar</button>
        </form>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Turno</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($usuarios): ?>
                        <?php foreach ($usuarios as $usuario): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($usuario['id']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['nome']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['turno']); ?></td>
                            <td>
                                <a href="editar_usuario.php?id=<?php echo $usuario['id']; ?>" class="btn btn-sm btn-warning">Editar</a>
                                <a href="excluir_usuario.php?id=<?php echo $usuario['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir este usuário?');">Excluir</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">Nenhum usuário cadastrado.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include '../includes/footer.php'; ?>

