<?php
// admin/cadastrar_onibus.php
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identificador  = trim($_POST['identificador']);
    $ponto_partida  = trim($_POST['ponto_partida']);

    if(empty($identificador) || empty($ponto_partida)) {
        $message = "Preencha os campos obrigatórios.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO buses (identificador, ponto_partida) VALUES (:identificador, :ponto_partida)");
        if ($stmt->execute([
            'identificador' => $identificador,
            'ponto_partida' => $ponto_partida
        ])) {
            $message = "Ônibus cadastrado com sucesso!";
        } else {
            $message = "Erro ao cadastrar ônibus.";
        }
    }
}

// Área de pesquisa e listagem de ônibus
$busca = isset($_GET['busca']) ? trim($_GET['busca']) : '';
if ($busca != '') {
    $stmtList = $pdo->prepare("SELECT * FROM buses WHERE identificador LIKE :busca OR ponto_partida LIKE :busca ORDER BY id DESC");
    $stmtList->execute(['busca' => "%$busca%"]);
} else {
    $stmtList = $pdo->query("SELECT * FROM buses ORDER BY id DESC");
}
$buses = $stmtList->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include '../includes/header.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <h2>Cadastrar Ônibus</h2>
        <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <form method="post" action="cadastrar_onibus.php">
            <div class="form-group">
                <label for="identificador">Identificador do Ônibus:</label>
                <input type="text" name="identificador" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="ponto_partida">Ponto de Partida:</label>
                <input type="text" name="ponto_partida" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
        
        <!-- Área de pesquisa e listagem -->
        <hr>
        <h3 class="mt-4">Ônibus Cadastrados</h3>
        <form method="get" action="cadastrar_onibus.php" class="form-inline mb-3">
            <input type="text" name="busca" class="form-control mr-2" placeholder="Pesquisar por identificador ou ponto" value="<?php echo htmlspecialchars($busca); ?>">
            <button type="submit" class="btn btn-secondary">Pesquisar</button>
        </form>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Identificador</th>
                        <th>Ponto de Partida</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($buses): ?>
                        <?php foreach ($buses as $bus): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($bus['id']); ?></td>
                            <td><?php echo htmlspecialchars($bus['identificador']); ?></td>
                            <td><?php echo htmlspecialchars($bus['ponto_partida']); ?></td>
                            <td>
                                <a href="editar_onibus.php?id=<?php echo $bus['id']; ?>" class="btn btn-sm btn-warning">Editar</a>
                                <a href="excluir_onibus.php?id=<?php echo $bus['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir este ônibus?');">Excluir</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center">Nenhum ônibus cadastrado.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include '../includes/footer.php'; ?>

