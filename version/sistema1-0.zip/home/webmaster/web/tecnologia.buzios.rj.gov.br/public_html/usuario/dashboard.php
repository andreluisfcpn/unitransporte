<?php
// usuario/dashboard.php
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('usuario');
?>
<?php include '../includes/header.php'; ?>
<div class="row">
    <div class="col">
        <h2>Dashboard do Usuário</h2>
        <ul class="list-group">
            <li class="list-group-item"><a href="perfil.php">Meu Perfil</a></li>
            <li class="list-group-item"><a href="gerar_qr.php">Gerar QR Code</a></li>
            <li class="list-group-item"><a href="historico_viagens.php">Histórico de Viagens</a></li>
        </ul>
    </div>
</div>
<?php include '../includes/footer.php'; ?>

