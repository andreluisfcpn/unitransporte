<?php
// usuario/historico_viagens.php
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('usuario');

$stmt = $pdo->prepare("SELECT * FROM trips WHERE user_id = :user_id ORDER BY data_viagem DESC");
$stmt->execute(['user_id' => $_SESSION['user']['id']]);
$viagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include '../includes/header.php'; ?>
<div class="row">
    <div class="col">
        <h2>Histórico de Viagens</h2>
        <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Data da Viagem</th>
                    <th>Status</th>
                    <th>Mensagem</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($viagens as $v): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($v['data_viagem']); ?></td>
                        <td><?php echo htmlspecialchars($v['status']); ?></td>
                        <td><?php echo htmlspecialchars($v['mensagem']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<?php include '../includes/footer.php'; ?>

