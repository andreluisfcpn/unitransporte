<?php
// usuario/perfil.php
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('usuario');

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $endereco = trim($_POST['endereco']);
    
    if(empty($endereco)) {
        $message = "O endereço não pode ficar em branco.";
    } else {
        $stmt = $pdo->prepare("UPDATE users SET endereco = :endereco WHERE id = :id");
        if ($stmt->execute(['endereco' => $endereco, 'id' => $_SESSION['user']['id']])) {
            $message = "Perfil atualizado com sucesso!";
            $_SESSION['user']['endereco'] = $endereco;
        } else {
            $message = "Erro ao atualizar perfil.";
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $_SESSION['user']['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php include '../includes/header.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <h2>Meu Perfil</h2>
        <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <form method="post" action="perfil.php">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" class="form-control" value="<?php echo htmlspecialchars($user['nome']); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="endereco">Endereço:</label>
                <input type="text" name="endereco" class="form-control" value="<?php echo htmlspecialchars($user['endereco']); ?>">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Atualizar Perfil</button>
        </form>
    </div>
</div>
<?php include '../includes/footer.php'; ?>

