<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema Ônibus Universitário</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <header class="bg-dark text-white p-3">
        <div class="container">
            <h1 class="mb-0">Sistema Ônibus Universitário</h1>
            <?php if(isset($_SESSION['user'])): ?>
            <nav class="mt-2">
                <a href="/logout.php" class="text-white">Sair</a>
            </nav>
            <?php endif; ?>
        </div>
    </header>
    <main class="container my-4">
