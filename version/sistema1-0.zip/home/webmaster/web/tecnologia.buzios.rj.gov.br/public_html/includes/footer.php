    </main>
    <footer class="bg-dark text-white p-3 mt-4">
        <div class="container text-center">
            <p>&copy; <?php echo date("Y"); ?> Universidade. Todos os direitos reservados.</p>
        </div>
    </footer>
    <!-- jQuery e Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>
