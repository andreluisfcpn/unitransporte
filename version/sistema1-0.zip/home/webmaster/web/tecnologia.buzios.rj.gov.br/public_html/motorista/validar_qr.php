<?php
// motorista/validar_qr.php
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('motorista');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Validação de QR Code</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    #qr-video {
      width: 100%;
      max-width: 500px;
      height: 300px;
      background-color: #000;
      margin: 20px auto;
      border: 1px solid #ccc;
    }
  </style>
</head>
<body>
<?php include '../includes/header.php'; ?>
<div class="container text-center">
  <h2 class="mt-4">Scanner de QR Code</h2>
  <p>Aponte a câmera para o QR Code fixo do usuário.</p>
  <video id="qr-video"></video>
</div>

<!-- Modal para exibir os dados do usuário -->
<div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="userModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 id="userModalLabel" class="modal-title">Dados do Usuário</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar" id="closeModalBtn">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modalUserInfo">
        <!-- Dados do usuário serão exibidos aqui -->
      </div>
      <div class="modal-footer">
        <button type="button" id="recuseBtn" class="btn btn-danger">Recusar</button>
        <button type="button" id="confirmBtn" class="btn btn-success">Confirmar</button>
      </div>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Scripts: jQuery, Bootstrap JS e QrScanner -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script type="module">
import QrScanner from "https://unpkg.com/qr-scanner/qr-scanner.min.js";
QrScanner.WORKER_PATH = 'https://unpkg.com/qr-scanner/qr-scanner-worker.min.js';

let currentUserId = null;
let qrScanner = null;

function startScanner() {
  $("#userModal").modal('hide');
  currentUserId = null;
  if (qrScanner) {
    qrScanner.start().catch(err => {
      console.error("Erro ao reiniciar scanner:", err);
    });
    return;
  }
  qrScanner = new QrScanner(
    document.getElementById('qr-video'),
    result => {
      console.log("QR Code detectado:", result);
      qrScanner.stop().then(() => {
        processQRCode(result);
      }).catch(err => {
        console.error("Erro ao parar scanner:", err);
      });
    },
    error => {
      console.warn("Erro na leitura do QR Code:", error);
    }
  );
  qrScanner.start().catch(err => {
    console.error("Erro ao iniciar scanner:", err);
    alert("Erro ao iniciar a câmera: " + err);
  });
}

function processQRCode(decodedText) {
  $.ajax({
    url: 'buscar_usuario.php',
    method: 'POST',
    dataType: 'json',
    data: { qrData: decodedText },
    success: function(response) {
      if(response.status === 'sucesso') {
        const user = response.data;
        currentUserId = user.id;
        $("#modalUserInfo").html("ID: " + user.id + "<br>Nome: " + user.nome + "<br>Email: " + user.email);
        $("#userModal").modal('show');
      } else {
        alert("Usuário não encontrado ou QR Code inválido.");
        startScanner();
      }
    },
    error: function(xhr, status, error) {
      console.error("Erro ao buscar usuário:", error);
      alert("Erro na comunicação com o servidor.");
      startScanner();
    }
  });
}

$("#recuseBtn").click(function(){
  currentUserId = null;
  $("#userModal").modal('hide');
  setTimeout(() => { startScanner(); }, 1000);
});

$("#confirmBtn").click(function(){
  if (currentUserId) {
    $.ajax({
      url: 'confirmar_viagem.php',
      method: 'POST',
      dataType: 'json',
      data: { userId: currentUserId },
      success: function(response) {
        if(response.status === 'sucesso') {
          alert("Usuário confirmado. Viagem registrada.");
        } else {
          alert("Erro: " + response.mensagem);
        }
        currentUserId = null;
        $("#userModal").modal('hide');
        setTimeout(() => { startScanner(); }, 1000);
      },
      error: function(xhr, status, error) {
        console.error("Erro ao confirmar viagem:", error);
        alert("Erro na comunicação com o servidor.");
        setTimeout(() => { startScanner(); }, 1000);
      }
    });
  }
});

$("#closeModalBtn").click(function(){
  currentUserId = null;
  setTimeout(() => { startScanner(); }, 1000);
});

$(document).ready(function(){
  startScanner();
});
</script>
</body>
</html>

