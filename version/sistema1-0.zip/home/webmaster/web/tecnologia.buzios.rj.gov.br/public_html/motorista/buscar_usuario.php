<?php
// motorista/buscar_usuario.php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'motorista') {
  http_response_code(403);
  echo json_encode(['status' => 'erro', 'mensagem' => 'Acesso negado.']);
  exit;
}

if (!isset($_POST['qrData'])) {
  echo json_encode(['status' => 'erro', 'mensagem' => 'QR Data não fornecido.']);
  exit;
}

$qrDataEncoded = trim($_POST['qrData']);
$qrDataDecoded = rawurldecode($qrDataEncoded);
$userData = json_decode($qrDataDecoded, true);

if (!$userData || !isset($userData['id'])) {
  echo json_encode(['status' => 'erro', 'mensagem' => 'QR Code inválido.']);
  exit;
}

$userId = $userData['id'];

$stmt = $pdo->prepare("SELECT id, nome, email, turno FROM users WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
  echo json_encode(['status' => 'sucesso', 'data' => $user]);
} else {
  echo json_encode(['status' => 'erro', 'mensagem' => 'Usuário não encontrado.']);
}
?>

