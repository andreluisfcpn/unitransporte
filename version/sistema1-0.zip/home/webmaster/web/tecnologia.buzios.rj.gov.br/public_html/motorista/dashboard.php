<?php
// motorista/dashboard.php
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('motorista');
?>
<?php include '../includes/header.php'; ?>
<div class="row">
    <div class="col">
        <h2>Dashboard do Motorista</h2>
        <ul class="list-group">
            <li class="list-group-item"><a href="validar_qr.php">Validar QR Code</a></li>
            <li class="list-group-item"><a href="historico_validacoes.php">Histórico de Validações</a></li>
        </ul>
    </div>
</div>
<?php include '../includes/footer.php'; ?>

