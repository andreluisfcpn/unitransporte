<?php
// processa_validacao.php
// Para ambiente de desenvolvimento (remova ou desative em produção)
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../config.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

try {
    // Verifica se o usuário logado é um motorista
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'motorista') {
        http_response_code(403);
        echo json_encode(['status' => 'erro', 'mensagem' => 'Acesso negado.']);
        exit;
    }
    
    // Lê o conteúdo bruto da requisição
    $rawInput = file_get_contents('php://input');
    error_log("processa_validacao.php - Raw input: " . $rawInput);
    
    $input = json_decode($rawInput, true);
    if (!$input) {
        error_log("processa_validacao.php - Falha ao decodificar o JSON do input.");
    }
    
    if (!isset($input['qrData'])) {
        error_log("processa_validacao.php - 'qrData' não fornecido.");
        echo json_encode(['status' => 'erro', 'mensagem' => 'QR Data não fornecido.']);
        exit;
    }
    
    // Pega a string URL-encoded e remove espaços indesejados
    $qrDataEncoded = trim($input['qrData']);
    error_log("processa_validacao.php - QR Data Encoded: " . $qrDataEncoded);
    
    // Recupera o JSON original via URL decoding
    $jsonDecoded = rawurldecode($qrDataEncoded);
    error_log("processa_validacao.php - JSON após rawurldecode: " . $jsonDecoded);
    
    // Decodifica o JSON em um array
    $decoded = json_decode($jsonDecoded, true);
    if (!$decoded) {
        error_log("processa_validacao.php - Falha ao decodificar JSON: " . $jsonDecoded);
        echo json_encode(['status' => 'nao_autorizado', 'mensagem' => 'QR Code inválido.']);
        exit;
    }
    error_log("processa_validacao.php - Decoded array: " . print_r($decoded, true));
    
    // Verifica se o array contém o campo "id" (não vazio)
    if (!isset($decoded['id']) || $decoded['id'] === "") {
        error_log("processa_validacao.php - 'id' ausente ou vazio: " . print_r($decoded, true));
        echo json_encode(['status' => 'nao_autorizado', 'mensagem' => 'Dados do QR Code incompletos.']);
        exit;
    }
    
    $userId = $decoded['id'];
    $hoje = date("Y-m-d");
    
    // Verifica quantas viagens o usuário já realizou hoje
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM trips WHERE user_id = :user_id AND DATE(data_viagem) = :hoje");
    $stmt->execute(['user_id' => $userId, 'hoje' => $hoje]);
    $viagensRealizadas = $stmt->fetchColumn();
    error_log("processa_validacao.php - Viagens realizadas para user $userId em $hoje: " . $viagensRealizadas);
    
    if ($viagensRealizadas >= 2) {
        $status = 'nao_autorizado';
        $mensagem = 'Limite diário de viagens atingido.';
    } else {
        $status = 'autorizado';
        $mensagem = 'Viagem autorizada.';
        // Registra a viagem – ajuste o bus_id conforme sua lógica
        $bus_id = 1;
        $stmt = $pdo->prepare("INSERT INTO trips (user_id, bus_id, motorista_id, data_viagem, status, mensagem)
                               VALUES (:user_id, :bus_id, :motorista_id, NOW(), :status, :mensagem)");
        $stmt->execute([
            'user_id'      => $userId,
            'bus_id'       => $bus_id,
            'motorista_id' => $_SESSION['user']['id'],
            'status'       => $status,
            'mensagem'     => $mensagem
        ]);
    }
    
    echo json_encode(['status' => $status, 'mensagem' => $mensagem]);
    
} catch (Exception $e) {
    error_log("processa_validacao.php - Exception: " . $e->getMessage());
    echo json_encode(['status' => 'erro', 'mensagem' => 'Erro interno: ' . $e->getMessage()]);
}
?>

