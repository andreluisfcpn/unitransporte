<?php
// motorista/confirmar_viagem.php
session_start();
require_once '../config.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'motorista') {
  http_response_code(403);
  echo json_encode(['status' => 'erro', 'mensagem' => 'Acesso negado.']);
  exit;
}

if (!isset($_POST['userId'])) {
  echo json_encode(['status' => 'erro', 'mensagem' => 'ID do usuário não fornecido.']);
  exit;
}

$userId = intval($_POST['userId']);
$hoje = date("Y-m-d");

$stmt = $pdo->prepare("SELECT COUNT(*) FROM trips WHERE user_id = :user_id AND DATE(data_viagem) = :hoje");
$stmt->execute(['user_id' => $userId, 'hoje' => $hoje]);
$viagensRealizadas = $stmt->fetchColumn();

if ($viagensRealizadas >= 2) {
  echo json_encode(['status' => 'erro', 'mensagem' => 'Limite diário de viagens atingido.']);
  exit;
}

$bus_id = 1;
$stmt = $pdo->prepare("INSERT INTO trips (user_id, bus_id, motorista_id, data_viagem, status, mensagem)
                       VALUES (:user_id, :bus_id, :motorista_id, NOW(), 'autorizado', 'Viagem autorizada.')");
$stmt->execute([
  'user_id'      => $userId,
  'bus_id'       => $bus_id,
  'motorista_id' => $_SESSION['user']['id']
]);

echo json_encode(['status' => 'sucesso', 'mensagem' => 'Usuário confirmado. Viagem registrada.']);
?>

