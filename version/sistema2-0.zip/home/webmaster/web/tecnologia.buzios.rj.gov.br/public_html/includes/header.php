<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define o link para o dashboard com base na role do usuário
$userDashboardLink = '/login.php'; // padrão se não estiver logado
if (isset($_SESSION['user'])) {
    switch ($_SESSION['user']['role']) {
        case 'admin':
            $userDashboardLink = '/admin/dashboard.php';
            break;
        case 'motorista':
            $userDashboardLink = '/motorista/dashboard.php';
            break;
        case 'usuario':
            $userDashboardLink = '/usuario/dashboard.php';
            break;
        default:
            $userDashboardLink = '/login.php';
    }
}

// Define um título padrão caso não seja definido na página
if (!isset($pageTitle)) {
    $pageTitle = "Bem-vindo";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlspecialchars($pageTitle); ?> - Sec. Administração</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    :root {
      --buzios-azul: #003049; /* Cor inspirada no brasão de Búzios */
    }
    body {
      background-color: #f8f9fa;
      color: #343a40;
    }
    .navbar-buzios {
      background-color: var(--buzios-azul);
    }
    .navbar-buzios .navbar-brand,
    .navbar-buzios .breadcrumb-item a {
      color: #fff !important;
    }
    .navbar-brand img {
      height: 40px;
      margin-right: 10px;
    }
    .breadcrumb {
      background: transparent;
      margin-bottom: 0;
    }
    /* Sidebar estilos */
    .sidebar {
      position: fixed;
      top: 0;
      left: -250px;
      width: 250px;
      height: 100%;
      background-color: var(--buzios-azul);
      padding: 20px;
      box-shadow: 2px 0 5px rgba(0,0,0,0.5);
      transition: left 0.3s ease;
      z-index: 1050;
    }
    .sidebar.open {
      left: 0;
    }
    .sidebar .profile {
      color: #fff;
      margin-bottom: 20px;
    }
    .sidebar a {
      color: #fff;
      display: block;
      margin-bottom: 10px;
      text-decoration: none;
    }
    .hamburger {
      cursor: pointer;
      font-size: 24px;
      color: #fff;
      border: none;
      background: none;
      outline: none;
    }
    .btn-voltar {
      margin: 20px 0;
    }
  </style>
</head>
<body>
<nav class="navbar navbar-buzios navbar-expand-lg">
  <div class="container d-flex align-items-center justify-content-between">
    <div class="d-flex align-items-center">
      <!-- Botão hamburger para abrir o menu lateral -->
      <button class="hamburger mr-2" id="toggleSidebar">&#9776;</button>
      <a class="navbar-brand d-flex align-items-center" href="<?php echo $userDashboardLink; ?>">
        <img src="/assets/img/buzios_logo.png" alt="Búzios Logo">
        <span>Sec. Administração</span>
      </a>
    </div>
    <!-- Breadcrumb -->
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?php echo $userDashboardLink; ?>">Início</a></li>
      <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($pageTitle); ?></li>
    </ol>
  </div>
</nav>

<!-- Sidebar lateral -->
<div class="sidebar" id="sidebar">
  <div class="profile">
    <?php if(isset($_SESSION['user'])): ?>
      <h5><?php echo htmlspecialchars($_SESSION['user']['nome']); ?></h5>
      <p><?php echo htmlspecialchars($_SESSION['user']['email']); ?></p>
    <?php else: ?>
      <h5>Bem-vindo</h5>
    <?php endif; ?>
  </div>
  <a href="<?php echo $userDashboardLink; ?>">Dashboard</a>
  <a href="/logout.php">Sair</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
  // Toggle do sidebar
  document.getElementById('toggleSidebar').addEventListener('click', function(e) {
    e.stopPropagation();
    var sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
  });

  // Se clicar fora do sidebar, ele é recolhido
  $(document).on('click', function(event) {
    var $target = $(event.target);
    if(!$target.closest('#sidebar').length && !$target.closest('#toggleSidebar').length) {
      $('#sidebar').removeClass('open');
    }
  });
</script>

<!-- Início do conteúdo principal -->
<div class="content" id="content">

