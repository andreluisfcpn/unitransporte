<?php 
$pageTitle = "Perfil"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('usuario');

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $endereco = trim($_POST['endereco']);
    
    if(empty($endereco)) {
        $message = "O endereço não pode ficar em branco.";
    } else {
        $stmt = $pdo->prepare("UPDATE users SET endereco = :endereco WHERE id = :id");
        if ($stmt->execute(['endereco' => $endereco, 'id' => $_SESSION['user']['id']])) {
            $message = "Perfil atualizado com sucesso!";
            $_SESSION['user']['endereco'] = $endereco;
        } else {
            $message = "Erro ao atualizar perfil.";
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $_SESSION['user']['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Meu Perfil</h2>
        </div>
        <div class="card-body">
          <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
          <?php endif; ?>
          <form method="post" action="perfil.php">
            <div class="form-group">
              <label for="nome">Nome:</label>
              <input type="text" name="nome" class="form-control" value="<?php echo htmlspecialchars($user['nome']); ?>" disabled>
            </div>
            <div class="form-group">
              <label for="email">Email:</label>
              <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
            </div>
            <div class="form-group">
              <label for="endereco">Endereço:</label>
              <input type="text" name="endereco" class="form-control" value="<?php echo htmlspecialchars($user['endereco']); ?>">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Atualizar Perfil</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

