<?php
$pageTitle = "Início"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('motorista');
include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Dashboard do Motorista</h2>
        </div>
        <div class="card-body">
          <ul class="list-group">
            <li class="list-group-item">
              <a href="validar_qr.php" class="stretched-link">Validar QR Code</a>
            </li>
            <li class="list-group-item">
              <a href="historico_validacoes.php" class="stretched-link">Histórico de Validações</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

