<?php 
$pageTitle = "Início"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');
include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Dashboard do Administrador</h2>
        </div>
        <div class="card-body">
          <ul class="list-group">
            <li class="list-group-item">
              <a href="cadastrar_usuario.php" class="stretched-link">Cadastrar Usuário</a>
            </li>
            <li class="list-group-item">
              <a href="cadastrar_motorista.php" class="stretched-link">Cadastrar Motorista</a>
            </li>
            <li class="list-group-item">
              <a href="cadastrar_onibus.php" class="stretched-link">Cadastrar Ônibus</a>
            </li>
            <li class="list-group-item">
              <a href="relatorio_usuarios.php" class="stretched-link">Relatório de Usuários</a>
            </li>
            <li class="list-group-item">
              <a href="relatorio_motoristas.php" class="stretched-link">Relatório de Motoristas</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

