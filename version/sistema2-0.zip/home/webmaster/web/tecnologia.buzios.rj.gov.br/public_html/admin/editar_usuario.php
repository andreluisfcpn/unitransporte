<?php
$pageTitle = "Editar Usuário"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

// Verifica se o ID do usuário foi passado via GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: cadastrar_usuario.php");
    exit;
}
$userId = intval($_GET['id']);

$message = "";
// Se o formulário for submetido, atualiza os dados do usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = trim($_POST['nome']);
    $email    = trim($_POST['email']);
    $endereco = trim($_POST['endereco']);
    $turno    = trim($_POST['turno']);
    $senha    = trim($_POST['senha']); // Nova senha, opcional

    if (empty($nome) || empty($email)) {
        $message = "Preencha os campos obrigatórios (Nome e Email).";
    } else {
        if (!empty($senha)) {
            // Se uma nova senha for informada, atualize também o campo 'senha'
            $senhaMD5 = md5($senha);
            $stmt = $pdo->prepare("UPDATE users 
                                   SET nome = :nome, email = :email, endereco = :endereco, turno = :turno, senha = :senha 
                                   WHERE id = :id");
            $params = [
                'nome'     => $nome,
                'email'    => $email,
                'endereco' => $endereco,
                'turno'    => $turno,
                'senha'    => $senhaMD5,
                'id'       => $userId
            ];
        } else {
            // Se não, atualiza apenas os demais campos
            $stmt = $pdo->prepare("UPDATE users 
                                   SET nome = :nome, email = :email, endereco = :endereco, turno = :turno 
                                   WHERE id = :id");
            $params = [
                'nome'     => $nome,
                'email'    => $email,
                'endereco' => $endereco,
                'turno'    => $turno,
                'id'       => $userId
            ];
        }
        if ($stmt->execute($params)) {
            $message = "Usuário atualizado com sucesso!";
        } else {
            $message = "Erro ao atualizar usuário.";
        }
    }
}

// Recupera os dados atuais do usuário
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    echo "Usuário não encontrado.";
    exit;
}

include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Editar Usuário</h2>
        </div>
        <div class="card-body">
          <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
          <?php endif; ?>
          <form method="post" action="editar_usuario.php?id=<?php echo $userId; ?>">
            <div class="form-group">
              <label for="nome">Nome:</label>
              <input type="text" name="nome" class="form-control" value="<?php echo htmlspecialchars($user['nome']); ?>" required>
            </div>
            <div class="form-group">
              <label for="email">Email:</label>
              <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
              <label for="endereco">Endereço:</label>
              <input type="text" name="endereco" class="form-control" value="<?php echo htmlspecialchars($user['endereco']); ?>">
            </div>
            <div class="form-group">
              <label for="turno">Turno:</label>
              <select name="turno" class="form-control" required>
                <option value="manha" <?php echo ($user['turno'] == 'manha' ? 'selected' : ''); ?>>Manhã</option>
                <option value="tarde" <?php echo ($user['turno'] == 'tarde' ? 'selected' : ''); ?>>Tarde</option>
                <option value="noite" <?php echo ($user['turno'] == 'noite' ? 'selected' : ''); ?>>Noite</option>
              </select>
            </div>
            <div class="form-group">
              <label for="senha">Nova Senha (deixe em branco para manter a atual):</label>
              <input type="password" name="senha" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Atualizar Usuário</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>
