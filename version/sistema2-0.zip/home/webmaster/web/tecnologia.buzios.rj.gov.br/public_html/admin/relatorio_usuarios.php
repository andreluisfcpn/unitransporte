<?php 
$pageTitle = "Relatório de Usuários"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

$stmt = $pdo->query("SELECT u.nome, t.data_viagem, t.status, t.mensagem 
                     FROM trips t 
                     INNER JOIN users u ON t.user_id = u.id 
                     ORDER BY t.data_viagem DESC");
$relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-10">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Relatório de Usuários</h2>
        </div>
        <div class="card-body">
          <?php if(empty($relatorios)): ?>
            <p class="text-center">Nenhum relatório disponível.</p>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table table-bordered">
                <thead class="thead-dark">
                  <tr>
                    <th>Nome do Usuário</th>
                    <th>Data da Viagem</th>
                    <th>Status</th>
                    <th>Mensagem</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($relatorios as $rel): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($rel['nome']); ?></td>
                      <td><?php echo htmlspecialchars($rel['data_viagem']); ?></td>
                      <td><?php echo htmlspecialchars($rel['status']); ?></td>
                      <td><?php echo htmlspecialchars($rel['mensagem']); ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>

