<?php
$pageTitle = "Editar Ônibus"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

// Verifica se o ID do ônibus foi passado via GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: cadastrar_onibus.php");
    exit;
}
$busId = intval($_GET['id']);

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identificador = trim($_POST['identificador']);
    $ponto_partida = trim($_POST['ponto_partida']);

    if(empty($identificador) || empty($ponto_partida)) {
        $message = "Preencha os campos obrigatórios.";
    } else {
        $stmt = $pdo->prepare("UPDATE buses SET identificador = :identificador, ponto_partida = :ponto_partida WHERE id = :id");
        if ($stmt->execute([
            'identificador' => $identificador,
            'ponto_partida' => $ponto_partida,
            'id' => $busId
        ])) {
            $message = "Ônibus atualizado com sucesso!";
        } else {
            $message = "Erro ao atualizar ônibus.";
        }
    }
}

// Recupera os dados do ônibus
$stmt = $pdo->prepare("SELECT * FROM buses WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $busId]);
$bus = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$bus) {
    echo "Ônibus não encontrado.";
    exit;
}

include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Editar Ônibus</h2>
        </div>
        <div class="card-body">
          <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
          <?php endif; ?>
          <form method="post" action="editar_onibus.php?id=<?php echo $busId; ?>">
            <div class="form-group">
              <label for="identificador">Identificador do Ônibus:</label>
              <input type="text" name="identificador" class="form-control" value="<?php echo htmlspecialchars($bus['identificador']); ?>" required>
            </div>
            <div class="form-group">
              <label for="ponto_partida">Ponto de Partida:</label>
              <input type="text" name="ponto_partida" class="form-control" value="<?php echo htmlspecialchars($bus['ponto_partida']); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Atualizar Ônibus</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>
