<?php
$pageTitle = "Editar Motorista"; // Título desta página
require_once '../config.php';
require_once '../includes/auth.php';
requireRole('admin');

// Verifica se o ID do motorista foi passado via GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: cadastrar_motorista.php");
    exit;
}
$motoristaId = intval($_GET['id']);

$message = "";
// Se o formulário for submetido, atualiza os dados do motorista
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = trim($_POST['nome']);
    $email    = trim($_POST['email']);
    $endereco = trim($_POST['endereco']);
    $senha    = trim($_POST['senha']); // Nova senha opcional

    if (empty($nome) || empty($email)) {
        $message = "Preencha os campos obrigatórios (Nome e Email).";
    } else {
        if (!empty($senha)) {
            // Se nova senha for informada, atualiza também o campo senha
            $senhaMD5 = md5($senha);
            $stmt = $pdo->prepare("UPDATE users 
                                   SET nome = :nome, email = :email, endereco = :endereco, senha = :senha 
                                   WHERE id = :id AND role = 'motorista'");
            $params = [
                'nome'     => $nome,
                'email'    => $email,
                'endereco' => $endereco,
                'senha'    => $senhaMD5,
                'id'       => $motoristaId
            ];
        } else {
            // Atualiza apenas os demais campos
            $stmt = $pdo->prepare("UPDATE users 
                                   SET nome = :nome, email = :email, endereco = :endereco 
                                   WHERE id = :id AND role = 'motorista'");
            $params = [
                'nome'     => $nome,
                'email'    => $email,
                'endereco' => $endereco,
                'id'       => $motoristaId
            ];
        }
        if ($stmt->execute($params)) {
            $message = "Motorista atualizado com sucesso!";
        } else {
            $message = "Erro ao atualizar motorista.";
        }
    }
}

// Recupera os dados atuais do motorista
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id AND role = 'motorista' LIMIT 1");
$stmt->execute(['id' => $motoristaId]);
$motorista = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$motorista) {
    echo "Motorista não encontrado.";
    exit;
}

include '../includes/header.php';
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header text-center">
          <h2>Editar Motorista</h2>
        </div>
        <div class="card-body">
          <?php if($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
          <?php endif; ?>
          <form method="post" action="editar_motorista.php?id=<?php echo $motoristaId; ?>">
            <div class="form-group">
              <label for="nome">Nome:</label>
              <input type="text" name="nome" class="form-control" value="<?php echo htmlspecialchars($motorista['nome']); ?>" required>
            </div>
            <div class="form-group">
              <label for="email">Email:</label>
              <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($motorista['email']); ?>" required>
            </div>
            <div class="form-group">
              <label for="endereco">Endereço:</label>
              <input type="text" name="endereco" class="form-control" value="<?php echo htmlspecialchars($motorista['endereco']); ?>">
            </div>
            <div class="form-group">
              <label for="senha">Nova Senha (deixe em branco para manter a atual):</label>
              <input type="password" name="senha" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Atualizar Motorista</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>
